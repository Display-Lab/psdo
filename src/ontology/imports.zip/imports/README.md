# Imports

Copies of external ontologies that are referenced in the fio-edit.owl should reside here as a convenience for the ontology editor (protege)

